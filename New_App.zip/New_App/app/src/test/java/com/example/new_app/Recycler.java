package com.example.new_app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Recycler extends AppCompatActivity {

    List<String> permissions,desc;
    List<Integer> images;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        permissions = new ArrayList<>();
        permissions.add("Phone Identity");
        permissions.add("SMS Read");
        permissions.add("Camera");
        permissions.add("Microphone");
        permissions.add("Location");

        desc = new ArrayList<>();
        desc.add("We need access to this to verify Mobile Number");
        desc.add("We need access to this to read sms");
        desc.add("We need access to this to click photos");
        desc.add("We need access to this to record voice");
        desc.add("We need access to this to get your location");

        images = new ArrayList<>();
        images.add(R.drawable.phone);
        images.add(R.drawable.sms);
        images.add(R.drawable.camera);
        images.add(R.drawable.mic);
        images.add(R.drawable.location);



    }
}