package com.example.new_app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    List<String> permissions,desc;
    List<Integer> images;


    public RecyclerAdapter(List<String> permissions, List<String> desc, List<Integer> images){
        this.permissions = permissions;
        this.desc = desc;
        this.images = images;
    }
    @Override
    public int getItemViewType(int position) {
        if (permissions.get(position).equals("Location")){
            return 2;
        }
        else if (permissions.get(position).equals("Phone Identity")){
            return 0;
        }
        else{
            return 1;
        }

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view;
        if (viewType == 0){
            view = layoutInflater.inflate(R.layout.recyclerrequest,parent,false);
            return new ViewHolderOne(view);
        }
        else if (viewType == 1){
            view = layoutInflater.inflate(R.layout.recycleritem,parent,false);
            return new ViewHolderTwo(view);
        }
        else{
            view = layoutInflater.inflate(R.layout.recyclerdone,parent,false);
            return new ViewHolderDone(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (permissions.get(position).equals("Phone Identity")){
            ViewHolderOne viewHolderOne = (ViewHolderOne) holder;
            viewHolderOne.title.setText(permissions.get(position));
            viewHolderOne.desc.setText(permissions.get(position));
            viewHolderOne.image.setImageResource(images.get(position));
        }
        else if(permissions.get(position).equals("Location")){
            ViewHolderDone viewHolderDone = (ViewHolderDone) holder;
            viewHolderDone.title.setText(permissions.get(position));
            viewHolderDone.image.setImageResource(images.get(position));
        }
        else{
            ViewHolderTwo viewHolderTwo = (ViewHolderTwo) holder;
            viewHolderTwo.title.setText(permissions.get(position));
            viewHolderTwo.desc.setText(desc.get(position));
            viewHolderTwo.image.setImageResource(images.get(position));

        }
    }

    @Override
    public int getItemCount() {
        return permissions.size();
    }

    class ViewHolderOne extends RecyclerView.ViewHolder{

        TextView title,desc;
        ImageView image;

        public ViewHolderOne(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.textrequest);
            desc = itemView.findViewById(R.id.descrequest);
            image = itemView.findViewById(R.id.imgrequest);

        }
    }

    class ViewHolderTwo extends RecyclerView.ViewHolder{

        TextView title,desc;
        ImageView image;

        public ViewHolderTwo(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.titleitem);
            desc = itemView.findViewById(R.id.descitem);
            image = itemView.findViewById(R.id.imgitem);

        }
    }

    class ViewHolderDone extends RecyclerView.ViewHolder{

        TextView title;
        ImageView image;

        public ViewHolderDone(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.titledone);
            image = itemView.findViewById(R.id.imgdone);

        }
    }

}

