package com.example.new_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

public class Input1 extends AppCompatActivity {

    Button button;

    CustomEditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_input1);
        getSupportActionBar().hide();
        editText = findViewById(R.id.editext1);
        editText.requestFocus();
        Intent intent = new Intent(this,input2.class);
        button = findViewById(R.id.emailbutton);
        button.setOnClickListener(view -> {
            if (TextUtils.isEmpty(editText.getText())){
                editText.setError("Required");
            }
            else {
                startActivity(intent);
            }
        });
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
    }
}