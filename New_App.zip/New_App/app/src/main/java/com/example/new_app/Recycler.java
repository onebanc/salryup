package com.example.new_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class Recycler extends AppCompatActivity {

    List<String> permissions,desc;
    List<Integer> images;

    ConstraintLayout constraintLayout;

    Button button;

    RecyclerView recyclerView;
    RecyclerAdapter recyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_recycler);
        button = findViewById(R.id.input);
        Intent intent = new Intent(this,Input.class);
        button.setOnClickListener(view -> {
            startActivity(intent);
        });
        getSupportActionBar().hide();

        permissions = new ArrayList<>();
        permissions.add("Phone Identity");
        permissions.add("SMS Read");
        permissions.add("Camera");
        permissions.add("Microphone");
        permissions.add("Location");

        desc = new ArrayList<>();
        desc.add("We need access to this to verify Mobile Number");
        desc.add("We need access to this to read sms");
        desc.add("We need access to this to click photos");
        desc.add("We need access to this to record voice");
        desc.add("We need access to this to get your location");

        images = new ArrayList<>();
        images.add(R.drawable.phone);
        images.add(R.drawable.sms);
        images.add(R.drawable.camera);
        images.add(R.drawable.mic);
        images.add(R.drawable.tick);

        recyclerView = findViewById(R.id.recyclerview);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerAdapter = new RecyclerAdapter(permissions,desc,images);
        recyclerView.setAdapter(recyclerAdapter);






    }
}